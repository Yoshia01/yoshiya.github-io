// addボタンとdeleteボタンの処理を追加する
let addBtn = document.querySelector('#btn');
addBtn.addEventListener('click',function(){
                        let input_text = document.querySelector('#input').value;
                        let nakiko = document.createElement('li')
                        nakiko.classList.add('nakiko')                      
                        let oya = document.querySelector('.todo-list')                       
                         nakiko.textContent = input_text
                         oya.appendChild(nakiko)
                        let sakujo = document.createElement('div')
                         sakujo.classList.add('sakujo')

                         sakujo.textContent = "達成"
                         nakiko.appendChild(sakujo)
                         
                         sakujo.addEventListener('click',function(){nakiko.remove()})
                                                          // nakiko = this.parentElement
                                        } 
                       )                       

